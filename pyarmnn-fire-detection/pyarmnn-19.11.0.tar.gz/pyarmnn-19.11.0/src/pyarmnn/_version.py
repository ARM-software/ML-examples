# The confidential and proprietary information contained in this file may
# only be used by a person authorised under and to the extent permitted
# by a subsisting licensing agreement from ARM Limited or its affiliates.
#
# (C) COPYRIGHT 2019 ARM Limited or its affiliates.
# ALL RIGHTS RESERVED
#
# This entire notice must be reproduced on all copies of this file
# and copies of this file may only be made by a person if such person is
# permitted to do so under the terms of a subsisting license agreement
# from ARM Limited or its affiliates.
import os

version_info = (19, 11, 0)

__dev_version_env = os.getenv("PYARMNN_DEV_VER", "")

if __dev_version_env:
    __dev_version = "dev0"
    try:
        __dev_version = "dev{}".format(int(__dev_version_env))
    except ValueError:
        __dev_version = str(__dev_version_env)

    version_info = (*version_info, __dev_version)

__version__ = '.'.join(str(c) for c in version_info)
__arm_ml_version__ = '2{:03d}{:02d}{:02d}'.format(version_info[0], version_info[1], version_info[2])


def check_armnn_version(installed_armnn_version, expected_armnn_version=__arm_ml_version__):
    expected_armnn_version = expected_armnn_version[:-2]  # cut off minor patch version
    installed_armnn_version = installed_armnn_version[:-2]  # cut off minor patch version
    assert expected_armnn_version == installed_armnn_version, \
        "Expected ArmNN version is {} but installed ArmNN version is {}".format(expected_armnn_version, installed_armnn_version)
