#  The confidential and proprietary information contained in this file may
#  only be used by a person authorised under and to the extent permitted
#  by a subsisting licensing agreement from ARM Limited or its affiliates.
#
#  (C) COPYRIGHT 2019 ARM Limited or its affiliates.
#  ALL RIGHTS RESERVED
#
#  This entire notice must be reproduced on all copies of this file
#  and copies of this file may only be made by a person if such person is
#  permitted to do so under the terms of a subsisting license agreement
#  from ARM Limited or its affiliates.
import os
import importlib


def test_rel_version():
    import pyarmnn._version as v
    importlib.reload(v)
    assert "dev" not in v.__version__
    del v


def test_dev_version():
    import pyarmnn._version as v
    os.environ["PYARMNN_DEV_VER"] = "1"

    importlib.reload(v)

    assert "19.11.0.dev1" == v.__version__

    del os.environ["PYARMNN_DEV_VER"]
    del v


def test_arm_version_not_affected():
    import pyarmnn._version as v
    os.environ["PYARMNN_DEV_VER"] = "1"

    importlib.reload(v)

    assert "20191100" == v.__arm_ml_version__

    del os.environ["PYARMNN_DEV_VER"]
    del v
