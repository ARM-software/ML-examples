#  The confidential and proprietary information contained in this file may
#  only be used by a person authorised under and to the extent permitted
#  by a subsisting licensing agreement from ARM Limited or its affiliates.
#
#  (C) COPYRIGHT 2019 ARM Limited or its affiliates.
#  ALL RIGHTS RESERVED
#
#  This entire notice must be reproduced on all copies of this file
#  and copies of this file may only be made by a person if such person is
#  permitted to do so under the terms of a subsisting license agreement
#  from ARM Limited or its affiliates.
import os
import platform
import pytest
import pyarmnn as ann


@pytest.fixture()
def get_supported_backends_setup(shared_data_folder):
    options = ann.CreationOptions()
    runtime = ann.IRuntime(options)

    get_device_spec = runtime.GetDeviceSpec()
    supported_backends = get_device_spec.GetSupportedBackends()

    yield supported_backends


def test_ownership():
    options = ann.CreationOptions()
    runtime = ann.IRuntime(options)

    device_spec = runtime.GetDeviceSpec()

    assert not device_spec.thisown


def test_to_string():
    options = ann.CreationOptions()
    runtime = ann.IRuntime(options)

    device_spec = runtime.GetDeviceSpec()
    expected_str = "IDeviceSpec {{ supportedBackends: [" \
                   "{}" \
                   "]}}".format(', '.join(map(lambda b: str(b), device_spec.GetSupportedBackends())))

    assert expected_str == str(device_spec)


def test_get_supported_backends_cpu_ref(get_supported_backends_setup):
    assert "CpuRef" in map(lambda b: str(b), get_supported_backends_setup)


@pytest.mark.juno
class TestNoneCpuRefBackends:

    @pytest.mark.parametrize("backend",["CpuAcc", "NpuAcc"])
    def test_get_supported_backends_cpu_acc(self, get_supported_backends_setup, backend):
        assert backend in map(lambda b: str(b), get_supported_backends_setup)

